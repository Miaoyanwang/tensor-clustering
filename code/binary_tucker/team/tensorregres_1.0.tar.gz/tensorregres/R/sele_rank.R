#' Rank selection
#'
#' Estimating an appropriate rank of given response tensor based BIC criterion. The choices of BIC
#'  aims to balance between the goodness-of-fit for the data and the degree of freedom in the population model.
#' @param tsr    Response tensor with 3 modes
#' @param X_covar1    covariate on first mode
#' @param X_covar2    covariate on second mode
#' @param X_covar3    covariate on third mode
#' @param rank_range  a matrix containing several rank candidates on each row
#' @param Nsim        max number of iterations if update do not convergence
#' @param cons        the constrain method, "non" for without constrain, "vanilla" for global scale down once at each iteration,
#'
#'                    "penalty" for add log-barrier penalty to object function.
#' @param dist        distribution of input tensor, see "details"
#' @return     a list containing the following:
#'
#'                    \code{rank} rank with minimal BIC
#'
#'                    \code{result}  a matrix containing each rank candidate and its logLik and BIC on each row

#' @details    For selecting rank, recommend using non-constrain version updating.
#'
#'             By default \code{sele_rank} performs a ordinary tucker rank selection on a certain mode if there is no covariate input on that mode.
#'             
#'             \code{dist} deal with three distributions of input tensor: binary, poisson and normal distribution.
#'
#'
#' @export


sele_rank = function(tsr, X_covar1 = NULL, X_covar2 = NULL, X_covar3 = NULL,rank_range,Nsim=10,cons = 'non',dist){
  #rank = 1:3
  whole_shape=dim(tsr)                      
  p=rep(0,3)
  if(is.null(X_covar1)) p[1]=whole_shape[1] else p[1]=dim(X_covar1)[2]
  if(is.null(X_covar2)) p[2]=whole_shape[2] else p[2]=dim(X_covar2)[2]
  if(is.null(X_covar3)) p[3]=whole_shape[3] else p[3]=dim(X_covar3)[2]
  
  
  #rank = expand.grid(rank1,rank2,rank3)
  #rank=rank[which(apply(rank,1,function(x){max(x)<= sqrt(prod(x))})==1),]
  #rank=rank[which(apply(rank,1,function(x){sum(x<=p)==3})),]
  rank_matrix=rank_range
  rank=as.matrix(rank_range)
  
  whole_shape = dim(tsr)
  rank = lapply(1:dim(rank)[1], function(x) rank[x,]) ## turn rank to a list
  upp = lapply(rank, FUN= update,tsr = tsr,X_covar1 = X_covar1,X_covar2 = X_covar2,X_covar3 = X_covar3, Nsim = Nsim, cons = cons,dist=dist)
  
  lglk= unlist(lapply(seq(length(upp)), function(x) tail(upp[[x]]$lglk,1)))
  BIC = unlist(lapply(seq(length(rank)), function(x) (prod(rank[[x]]) + sum((p-1-rank[[x]])*rank[[x]])) * log(prod(whole_shape))))
  BIC = -2*lglk + BIC
  rank_matrix=cbind(rank_matrix,lglk,BIC)
  
  return(list(rank = rank[[which(BIC == min(BIC))]],result=rank_matrix))
}






