#' tensor clustering by performing k-means on cp decomposition
#' 
#' tensor clustering by performing k-means on cp decomposition
#' @param x a three-dimensional array
#' @param range.k the range of k
#' @param range.r the range of r
#' @param range.l the range of l
#' @param multiplicative the number of components
#' @return a list with only one element: judgeX
#' 



cp_kmeans= function(x,range.k,range.r,range.l,multiplicative=1){
  
  krl = matrix(c(rep(1:length(range.k),each=length(range.r)*length(range.l)),
                 rep(1:length(range.r),times=length(range.k)*length(range.l)),
                 rep(rep(1:length(range.l),each=length(range.r)),times=length(range.k))),byrow=TRUE,
               nrow=3)
  krl_list = as.list(as.data.frame(krl))
  
  if (.Platform$OS.type == "windows") {
  bires = apply(krl,MARGIN=2,label_for_cp,x=x,multiplicative=multiplicative)
  CBIC = lapply(bires,tensor.calculateBIC, x=x)
  BIC = unlist(CBIC)
  } else {
    bires = mclapply(krl_list, label_for_cp, x=x, multiplicative=multiplicative, mc.cores=n.cores)
    CBIC = mclapply(bires,tensor.calculateBIC, x=x, mc.cores = n.cores)
    BIC = unlist(CBIC)
  }
  names(BIC) = apply(krl,MARGIN=2,FUN=function(x) paste(range.k[x[1]],range.r[x[2]],range.l[x[3]]))
  best = krl_list[[which(BIC == min(BIC))[1]]]
  return(label_for_cp(c(best),x,multiplicative))
}

