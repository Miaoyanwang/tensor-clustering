#' generate a random tensor
#' 
#' generate a random tensor
#' @param n the dimension of mode 1
#' @param p the dimension of mode 2
#' @param q the dimension of mode 3
#' @param k the clusters number of mode 1 
#' @param r the clusters number of mode 2
#' @param l the clusters number of mode 3 
#' @param error noise in rnorm
#' @param sort if TRUE, the data belongs to the same clusters would assemble together
#' @param sparse.percent the proportion of 0 mean in normal case; the proportion of 0 of each vector in multiplicative case
#' @param multiplicative if !=0, then produce overlapping multiplicative data, the numver refers to the number of overlapping
#' @param center if center sum(x) = 0
#' @param seed default is NULL, otherwise would set seedd to corresponding point
#' @param mumin ...
#' @param mumax ...
#' @param same_cluster if multiplicative !=0, TRUE means the overlapping clusters share the same structure
#' @return a list \code{x}
#'                \code{truthX}
#'                \code{truthCs} true distribution in mode 1
#'                \code{truthDs} true distribution in mode 2
#'                \code{truthEs} true distribution in mode 3
#'                \code{mus} 
#'                \code{binaryX}
#' 
get.data = function(n,p,q,k,r,l,error=3,sort=TRUE,sparse.percent=0,multiplicative=0,center=FALSE,seed=NULL,mumin = -3, mumax = 3, same_cluster = TRUE){
  if(!is.null(seed)) set.seed(seed)
  if(multiplicative == 0){
    mus = runif(k*r*l,mumin,mumax)#take the mean of k*r*l biclusters/cubes
    if(sparse.percent!=0) mus[1:floor(k*r*l*sparse.percent)] = 0
    mus = array(mus,c(k,r,l))
  } else {
    k = as.integer(k)
    m1 = list();m2 = list();m3 = list();d = 8
    mus = array(rep(0,k*l*r),c(k,r,l))
    for (i in 1:multiplicative){
      if(same_cluster == FALSE){
        m1[[i]] = runif(k,mumin,mumax)
        m2[[i]] = runif(r,mumin,mumax)
        m3[[i]] = runif(l,mumin,mumax)
        if(sparse.percent!=0){
          m1[[i]][-1:-floor(k*(1-sparse.percent))-floor(i*k*sparse.percent/multiplicative)] = 0
          m2[[i]][-1:-floor(r*(1-sparse.percent))-floor(i*r*sparse.percent/multiplicative)] = 0
          m3[[i]][-1:-floor(l*(1-sparse.percent))-floor(i*l*sparse.percent/multiplicative)] = 0
        }
        m1[[i]] = new("Tensor",3L,c(k,1L,1L),data=m1[[i]])
        m2[[i]] = matrix(m2[[i]],ncol=1)
        m3[[i]] = matrix(m3[[i]],ncol=1)
        mus<-mus + d*ttm(ttm(m1[[i]],m2[[i]],2),m3[[i]],3)@data
      } else {
        if(i==1)  {
          m1 = runif(k,mumin,mumax);m2 = runif(r,mumin,mumax);m3 = runif(l,mumin,mumax)
          m1[-1:-floor(k*(1-sparse.percent))] = 0
          m2[-1:-floor(r*(1-sparse.percent))] = 0
          m3[-1:-floor(l*(1-sparse.percent))] = 0
        } else{
          #print(m1)
          #print(i)
          #print(c((k-floor((i-1)*k/multiplicative)):k,1:(k-1-floor((i-1)*k/multiplicative))))
          m1 = m1[c((k-floor((i-1)*k/multiplicative)):k,1:(k-1-floor((i-1)*k/multiplicative)))]
          m2 = m2[c((r-floor((i-1)*r/multiplicative)):r,1:(r-1-floor((i-1)*r/multiplicative)))]
          m3 = m3[c((l-floor((i-1)*l/multiplicative)):l,1:(l-1-floor((i-1)*l/multiplicative)))]
        }
        m1t = new("Tensor",3L,c(k,1L,1L),data=m1)
        m2t = matrix(m2,ncol=1)
        m3t = matrix(m3,ncol=1)
        mus<-mus + d*ttm(ttm(m1t,m2t,2),m3t,3)@data
      }
    }
  }
  if(is.null(mus)) stop("multiplicative must be a positive integer!") 
  if (k!=1) truthCs = ReNumber(sample(1:k,n,replace=TRUE)) else truthCs = rep(1,n)
  if (r!=1) truthDs = ReNumber(sample(1:r,p,replace=TRUE)) else truthDs = rep(1,p)
  if (l!=1) truthEs = ReNumber(sample(1:l,q,replace=TRUE)) else truthEs = rep(1,q)
  
  ##### added by Miaoyan
  if(sort==TRUE){
      truthCs=sort(truthCs)
      truthDs=sort(truthDs)
      truthEs=sort(truthEs)
  }
  ######
  
  x = array(rnorm(n*p*q,mean=0,sd=error),dim = c(n,p,q))
  truthX = array(rep(0,n*p*q),c(n,p,q))
  for(i in 1:max(truthCs)){
    for(j in 1:max(truthDs)){
      for(m in 1:max(truthEs)){
        x[truthCs==i, truthDs==j, truthEs==m] = x[truthCs==i, truthDs==j, truthEs==m] + mus[i,j,m]
        truthX[truthCs==i, truthDs==j, truthEs==m] =  mus[i,j,m]
      }
    }
  }
  if (center == TRUE) x = x - mean(x)
  
  #### removed by Miaoyan
  #if(sort==TRUE){
  # truthX = reorderClusters(truthX,truthCs,truthDs,truthEs)$x
  # neworder = reorderClusters(x,truthCs,truthDs,truthEs)
  # binaryX = (truthX!=0)*1
  # result = list("x"=neworder$x,"truthX"=truthX,"truthCs"=neworder$Cs,"truthDs"=neworder$Ds,"truthEs"=neworder$Es,"mus"=mus,"binaryX"=binaryX)
  #} else {
    binaryX = (truthX!=0)*1
    result = list("x"=x,"truthX"=truthX,"truthCs"=truthCs,"truthDs"=truthDs,"truthEs"=truthEs,"mus"=mus,"binaryX"=binaryX)
   #}
  return(result)
}
