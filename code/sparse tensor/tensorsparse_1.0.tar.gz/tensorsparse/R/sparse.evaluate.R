#' evaluate the accuracy of the model when inputting a sparse tensor
#' 
#' evaluate the accuracy of the model when inputting a sparse tensor
#' @param bires the return list of label2()
#' @param data the return list of get.data()
#' @param show whether print the result
#' @param CER if true, it would return CER also

sparse.evaluate = function(bires, data, show=TRUE, CER=TRUE){
  npq=dim(data$x);n=npq[1];p=npq[2];q=npq[3]
  restensor<-(abs(bires$judgeX)>1e-10)*1
  totalzero<-sum(restensor==0)/(n*p*q)
  correctzero<-sum(restensor[which(data$binaryX==0)]==0)/sum(data$binaryX==0)
  correctone<-sum(restensor[which(data$binaryX==1)]==1)/(n*p*q-sum(data$binaryX==0))
  totalincorrect<-sum(abs(restensor-data$binaryX))/(n*p*q)
  mse = sum((bires$judgeX-data$truthX)^2)/n/p/q
  result = list(sparsityrate=totalzero, correctzerorate=correctzero,correctonerate=correctone,totalincorrectrate=totalincorrect,mse=mse)
  if (CER == TRUE){
    cerC<-1-adjustedRand(data$truthCs,bires$Cs,randMethod=c("Rand"))
    cerD<-1-adjustedRand(data$truthDs,bires$Ds,randMethod=c("Rand"))
    cerE<-1-adjustedRand(data$truthEs,bires$Es,randMethod=c("Rand"))
    if (show == TRUE) cat("CerC is", cerC, ", cerD is", cerD, ", cerE is", cerE, ".\n")
    result = list(sparsityrate=totalzero, correctzerorate=correctzero,correctonerate=correctone,totalincorrectrate=totalincorrect,cerC=cerC,cerD=cerD,cerE=cerE,mse=mse)
  }
  if(show == TRUE) cat("Total zero rate is", totalzero, ", correct zero rate is", correctzero, ", correct one rate is", correctone, ", total incorrect rate is", totalincorrect, ", mse is", mse,".\n")
  return(result)
}