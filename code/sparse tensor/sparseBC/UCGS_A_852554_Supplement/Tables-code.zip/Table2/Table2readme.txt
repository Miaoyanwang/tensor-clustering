Run both Table2_k2r4.R and Table2_k6r3.R to get the results for Table 2 in the manuscript.

Table2_k2r4.R gives the results for $k=2$ and $r=4$.
Table2_k6r3.R gives the results for $k=6$ and $r=3$.

