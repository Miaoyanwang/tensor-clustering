
Run all Table3n200p200.R, Table3n200p200lambda.R, Table3n200p500.R, and Table3n200p500lambda.R to get the results for Table 3.

Table3Functions.R contains function to run the simulation for sparse biclustering with lambda being specified.
Table3Functionslambda.R contains function to run the simulation for sparse biclustering with lambda automatically chosen using BIC.

Table3n200p200.R gives the results for n=200 and p=200
Table3n200p200lambda.R gives the results for n=200, p=200, and lambda automatically chosen using BIC.
Table3n200p500.R gives the results for n=200 and p=500
Table3n200p500lambda.R gives the results for n=200, p=250, and lambda automatically chosen using BIC.

