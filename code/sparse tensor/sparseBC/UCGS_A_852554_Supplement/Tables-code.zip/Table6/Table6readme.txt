
Run both Table6.R and Table6Lambda.R to get the results for Table 6.

Table6Function.R contains function to run the simulation for sparse biclustering with lambda being specified, and also other methods such as the ssvd.
Table6Functionlambda.R contains function to run the simulation for sparse biclustering with lambda automatically chosen using BIC.

Table6.R gives the results for all methods except for sparse biclustering with lambda automatically chosen.
Table6Lambda.R gives the results for sparse biclustering with lambda automatically chosen.