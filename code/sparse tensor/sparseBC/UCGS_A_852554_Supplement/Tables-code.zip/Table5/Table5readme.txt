
Run both Table5.R and Table5Lambda.R to get the results for Table 5.

Table5Function.R contains function to run the simulation for sparse biclustering with lambda being specified, and also other methods such as the ssvd.
Table5Functionlambda.R contains function to run the simulation for sparse biclustering with lambda automatically chosen using BIC.

Table5.R gives the results for all methods except for sparse biclustering with lambda automatically chosen.
Table5Lambda.R gives the results for sparse biclustering with lambda automatically chosen.