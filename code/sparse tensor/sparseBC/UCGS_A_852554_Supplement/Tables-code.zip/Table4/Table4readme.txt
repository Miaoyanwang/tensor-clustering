
Run all Table4n200p200.R, Table4n200p200lambda.R, Table4n200p500.R, and Table4n200p500lambda.R to get the results for Table 4.

Table4Functions.R contains function to run the simulation for sparse biclustering with lambda being specified, and also other methods such as the ssvd.
Table4Functionslambda.R contains function to run the simulation for sparse biclustering with lambda automatically chosen using BIC.

Table4n200p200.R gives the results for n=200 and p=200
Table4n200p200lambda.R gives the results for n=200, p=200, and lambda automatically chosen using BIC.
Table4n200p500.R gives the results for n=200 and p=500
Table4n200p500lambda.R gives the results for n=200, p=250, and lambda automatically chosen using BIC.

