#############################################################
# Reproduce Figure 2 in the manuscript
#############################################################
library(sparseBC)
library(fields)
# Picture for estimated mus

set.seed(5)
u<-c(10,9,8,7,6,5,4,3,rep(2,17),rep(0,75))
v<-c(10,-10,8,-8,5,-5,rep(3,5),rep(-3,5),rep(0,34))
u<-u/sqrt(sum(u^2))
v<-v/sqrt(sum(v^2))
d<-50
mus<-(d*u%*%t(v))
binaryX<-(mus!=0)*1
X<-mus+matrix(rnorm(100*50),100,50)
X<-X-mean(X)

KR<-sparseBC.choosekr(X,1:6,1:6,0,0.1)
k<-KR$estimated_kr[1]
r<-KR$estimated_kr[2]
biclustering<-sparseBC(X,k,r,10)
print(mean(biclustering$mus==0))

pdf(file="ssvdexample.pdf",width=12,height=4)
set.panel(1,3)
par(oma=c(0,0,0,4))
color=c(rainbow(15,start=0.5,end=0.6)[15:1],"white",rainbow(13,start=0.08,end=0.15)[13:1])
image(X,main="(a)",xaxt='n',yaxt='n',cex.main=2,axes=TRUE,col=color,zlim=c(-13,13))
color=c(rainbow(15,start=0.5,end=0.6)[15:1],"white",rainbow(15,start=0.08,end=0.15)[15:1])
image(mus,main="(b)",cex.main=2,axes=TRUE,xaxt='n',yaxt='n',col=color,zlim=c(-13,13))
image(biclustering$mus,main="(c)" ,cex.main=2,axes=TRUE,xaxt='n',yaxt='n',col=color,zlim=c(-13,13))
par(oma=c(0,0,0,1))
image.plot(biclustering$mus,col=color,horizontal=FALSE,legend.only=TRUE,zlim=c(-13,13))
dev.off()
