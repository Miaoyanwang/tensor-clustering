##############################################
# Produce Figure 1 in the manuscript
# A toy example to illustrate the results from k-means and sparse biclustering
##############################################
library(sparseBC)
set.seed(1)
n<-100
p<-200
K<-5
R<-5
truthCs<-rep(1:K, each=(n/K))
truthDs<-rep(1:R, each=(p/R))
mus<-runif(K*R,-3,3)
mus<-matrix(c(mus),nrow=K,ncol=R,byrow=FALSE)
x<-matrix(rnorm(n*p,mean=0,sd=5),nrow=n,ncol=p)

musmatrix<-matrix(NA,nrow=n,ncol=p)
for(i in 1:max(truthCs)){
  for(j in 1:max(truthDs)){ 
  x[truthCs==i,truthDs==j]<-x[truthCs==i,truthDs==j]+mus[i,j]
  musmatrix[truthCs==i,truthDs==j]<-mus[i,j]
  } 
}	

km.Cs<-kmeans(x,K,nstart=20)$cluster
km.Ds<-kmeans(t(x),R,nstart=20)$cluster
km.mus<-matrix(NA,nrow=n,ncol=p)
for(i in 1:n){
  for(j in 1:p){
  km.mus[i,j]<-mean(x[km.Cs==km.Cs[i],km.Ds==km.Ds[j]])		
  }
}
bicluster<-sparseBC(x,K,R,0)
bc.mus<-bicluster$mus

par(cex.main=1.5)
pdf("heatmapone.pdf")
heatmap(x,Rowv=NA,Colv=NA,main="(a)",scale="none",labRow=rep("",n), labCol=rep("",p),col=topo.colors(100),margin=c(20,20))
dev.off()

pdf("heatmaptwo.pdf")
heatmap(musmatrix,Rowv=NA,Colv=NA,main="(b)",scale="none",cex.main=20,labRow=rep("",n), labCol=rep("",p),col=topo.colors(100),margin=c(20,20))
dev.off()

pdf("heatmapthree.pdf")
heatmap(km.mus,Rowv=NA,Colv=NA,main="(c)",scale="none",cex.main=20,labRow=rep("",n), labCol=rep("",p),col=topo.colors(100),margin=c(20,20))
dev.off()

pdf("heatmapfour.pdf")
heatmap(bc.mus,Rowv=NA,Colv=NA,main="(d)",scale="none",cex.main=20,labRow=rep("",n), labCol=rep("",p),col=topo.colors(100),margin=c(20,20))
dev.off()
