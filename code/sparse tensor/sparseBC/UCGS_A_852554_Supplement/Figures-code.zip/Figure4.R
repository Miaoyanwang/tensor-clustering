########################
# Produce Figure 4 in the manuscript
# An analysis of the lung cancer data from the s4vd package
# We use K=4 and R=10, lambda=1500
########################
library(sparseBC)
library(fields)
data(lung)
truecluster<-as.numeric(as.factor(rownames(lung)))
cancersd<-apply(lung,2,sd)
minilung<-lung[,rank(cancersd)>=length(cancersd)-4999]

set.seed(5)
res<-sparseBC(minilung,4,10,1500) 

#########################
# Plot heatmap, arrange the genes so that 
# genes in same cluster are grouped together
#########################
heatmapMus<-NULL
for(i in 1:max(res$Ds)){
  heatmapMus<-cbind(heatmapMus,res$mus[,which(res$Ds==i)])
  }
pdf(file="lungheatmap.pdf",width=6,height=6)
color=c(rainbow(20,start=0.5,end=0.6)[20:1],"white","white",rainbow(20,start=0.08,end=0.15)[20:1])
image.plot(heatmapMus,horizontal=FALSE,col=color,axes=TRUE,zlim=c(-1,1),xaxt='n',yaxt='n')
dev.off()

