################################
# Reproduce Figure 3
################################
library(sparseBC)
library(fields)
set.seed(5)

u1<-c(10,9,8,7,6,5,4,3,rep(2,17),rep(0,75))
v1<-c(10,-10,8,-8,5,-5,rep(3,5),rep(-3,5),rep(0,34))
u1<-u1/sqrt(sum(u1^2))
v1<-v1/sqrt(sum(v1^2))
u2<-c(rep(0,13),10,9,8,7,6,5,4,3,rep(2,17),rep(0,62))
v2<-c(rep(0,9),10,-9,8,-7,6,-5,rep(4,5),rep(-3,5),rep(0,25))
u2<-u2/sqrt(sum(u2^2))
v2<-v2/sqrt(sum(v2^2))
d<-50
mus<-(d*u1%*%t(v1))+(d*u2%*%t(v2))
binaryX<-(mus!=0)*1

X<-mus+matrix(rnorm(100*50),100,50)
X<-X-mean(X)

KR<-sparseBC.choosekr(X,1:9,1:9,0,0.1)
k<-KR$estimated_kr[1]
r<-KR$estimated_kr[2]      

biclustering2<-sparseBC(X,k,r,70)

pdf(file="ssvdexample2.pdf",width=12,height=4)
set.panel(1,3)
par(oma=c(0,0,0,4))
color=c(rainbow(60,start=0.5,end=0.6)[60:1],"white","white",rainbow(60,start=0.08,end=0.15)[60:1])
image(X,main="(a)",cex.main=2,axes=TRUE,col=color,zlim=c(-13,13),xaxt='n',yaxt='n')
image(mus,main="(b)",cex.main=2,axes=TRUE,col=color,zlim=c(-12,12),xaxt='n',yaxt='n')
image(biclustering2$mus,main="(c)",cex.main=2,axes=TRUE,xaxt='n',yaxt='n',col=color,zlim=c(-12,12))
par(oma=c(0,0,0,1))
image.plot(biclustering2$mus,col=color,horizontal=FALSE,legend.only=TRUE,zlim=c(-12,12))
dev.off()













