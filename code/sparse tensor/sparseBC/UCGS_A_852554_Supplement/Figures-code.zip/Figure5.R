########################
# Produce Figure 5 in the manuscript
# We run MVN biclustering here
# We use K=4 and R=10, lambda=1500, alpha and beta = 0.35
########################
library(sparseBC)
library("fields")

data(lung)
truecluster<-as.numeric(as.factor(rownames(lung)))
cancersd<-apply(lung,2,sd)
minilung<-lung[,rank(cancersd)>=length(cancersd)-4999]


set.seed(1)
res<-matrixBC(minilung,4,10,1500,0.35,0.35,nstart=20)
save.image(file="results.RData")
print(res$Cs)
#########################
# Plot heatmap, arrange the genes so that 
# genes in same cluster are grouped together
#########################
heatmapMus<-NULL
for(i in 1:max(res$Ds)){
  heatmapMus<-cbind(heatmapMus,res$mus[,which(res$Ds==i)])
  }

pdf(file="matrixlungimage.pdf",width=6,height=6)
color=c(rainbow(20,start=0.5,end=0.6)[20:1],"white","white",rainbow(20,start=0.08,end=0.15)[20:1])
image.plot(heatmapMus,horizontal=FALSE,col=color,axes=TRUE,zlim=c(-0.5,0.5),xaxt='n',yaxt='n')
dev.off()
