rm(list=ls())
require(tensorsparse)

########################################
###   Table 2    #######################
########################################

n=40;p=40;q=40;k=3;r=5;l=4;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")


n=40;p=40;q=60;k=3;r=5;l=4;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")


n=40;p=60;q=60;k=3;r=5;l=4;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")


n=60;p=60;q=60;k=3;r=5;l=4;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")



n=40;p=40;q=40;k=5;r=2;l=2;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")


n=40;p=40;q=60;k=5;r=2;l=2;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")


n=40;p=60;q=60;k=5;r=2;l=2;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")


n=60;p=60;q=60;k=5;r=2;l=2;error=5;iteration=50
out = sim.choosekrl(n,p,q,k,r,l,error,iteration)
res<-Calculate(c(k,r,l),out)
reskr<-Calculatekrl(out)
cat("The krl choosed by bic:\n")
cat("The correct rate is", res,", meank=",reskr$meank, "(",reskr$sdek,"), meanr=",reskr$meanr, "(", reskr$sder, "), meanl=", reskr$meanl, "(", reskr$sdel, ").\n")

